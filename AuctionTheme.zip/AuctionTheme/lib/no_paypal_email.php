<?php
/***************************************************************************
*
*	AuctionTheme - copyright (c) - sitemile.com
*	The most popular auction theme for wordress on the internet. Launch your
*	auction site in minutes from purchasing. Turn-key solution.
*
*	Coder: Andrei Dragos Saioc
*	Email: sitemile[at]sitemile.com | andreisaioc[at]gmail.com
*	More info about the theme here: http://sitemile.com/p/auctionTheme
*	since v4.55
*
***************************************************************************/

	get_header();

?>
<div class="clear10"></div>

	
			<div class="my_box3">
            
            	<div class="box_title"><?php  printf(__("No PayPal email defined. Please contact seller.",'AuctionTheme')); ?></div>
                <div class="box_content">   
               <?php
			   
			   printf(__("Your seller does not have his PayPal email defined in his account. Contact seller and ask him to set his PayPal email so he can accept payments.",'AuctionTheme') );
			   ?> 
                
                <div class="clear10"></div>
               
             
    </div>
			</div>
	
        
        <div class="clear100"></div>
            
            
<?php

get_footer();

?>                        
<?php
/**
 * Part Name: WooCommerce Title
 */
?>

<header class="entry-header">
	<div class="container">
		<?php do_action ( 'ultra_woocommerce_title' ); ?><?php do_action ( 'ultra_woocommerce_breadcrumb' ); ?>
	</div><!-- .container -->
</header><!-- .entry-header -->	

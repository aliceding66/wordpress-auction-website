<?php
/**
 * The header for our theme.
 *
 * Displays all of the <head> section and everything up till <div id="content">
 *
 * @package ultra
 * @since ultra 0.9
 * @license GPL 2.0
 */
?><!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
<meta charset="<?php bloginfo( 'charset' ); ?>">
<link rel="profile" href="http://gmpg.org/xfn/11">
<link rel="pingback" href="<?php bloginfo( 'pingback_url' ); ?>">

<?php wp_head(); ?>
</head>

<body <?php body_class(); ?>>
<div id="page" class="hfeed site">
<div id="header_all">
        
	<a class="skip-link screen-reader-text" href="#content"><?php _e( 'Skip to content', 'ultra' ); ?></a>

	<?php get_template_part( 'parts/top-bar' );?>

<!--30/May/2016-->
<div style="float:left;" width="20%">
</div>
<div id="header_social">
<a href="http://www.facebook.com"><img src="http://sakirice.com/auctioncool/wp-content/uploads/2016/06/facebookicon.png" width="20" /></a>
<a href="http://www.linkedin.com"><img src="http://sakirice.com/auctioncool/wp-content/uploads/2016/06/linkedinicon.png" width="20" /></a>
<a href="http://www.google.ca"><img src="http://sakirice.com/auctioncool/wp-content/uploads/2016/06/googleplus.png" width="20" /></a>
<a href="http://www.twitter.com"><img src="http://sakirice.com/auctioncool/wp-content/uploads/2016/06/twitter.png" width="20" /></a>
<a href="http://www.pinterest.com"><img src="http://sakirice.com/auctioncool/wp-content/uploads/2016/06/pinterest.png" width="20" /></a>
<a href="http://www.wechat.com"><img src="http://sakirice.com/auctioncool/wp-content/uploads/2016/06/wechat.png" width="20" /></a>

<marquee behavior="scroll" style="background: url('http://www.auctionmaxx.com/Content/Images/bg.jpg') repeat center center; margin-left: 13em;" loop="-1" width="40%">
  <i><font id="demo" color="#009900">
</font></i>
</marquee> 
<script>
var d = new Date();
document.getElementById("demo").innerHTML = "<strong>Welcome</strong> Today's date is :"+ d.toDateString();
</script>
<div style="float:right;" width="10%">
<?php 
if(!is_user_logged_in())
	echo "<a href='http://sakirice.com/auctioncool/my-account'>Sign in /Register</a>";
      else {
       echo "Hello "; 
       $current_user = wp_get_current_user();
       echo  "<a href='http://sakirice.com/auctioncool/my-account?v=7516fd43adaa'>";
       echo  $current_user->user_login;
       echo  "</a>";
       echo "   ";
       echo '<a href="http://sakirice.com/auctioncool/my-account/customer-logout/">Sign Out</a>';}?></div>
	

</div>
	<header id="masthead" class="site-header<?php if ( siteorigin_setting( 'header_scale' ) ) { echo ' scale'; } if ( siteorigin_setting( 'navigation_responsive_menu' ) ) { echo ' responsive-menu'; } ?>" role="banner">
	
		<div class="container">
                        
			<div class="site-branding-container">

				<div class="site-branding">
					<a href="<?php echo esc_url( home_url( '/' ) ); ?>" rel="home">
						<?php ultra_display_logo(); ?>
					</a>
					<?php if ( get_bloginfo( 'description' ) && siteorigin_setting( 'header_tagline' ) ) : ?>
						<h2 class="site-description"><?php bloginfo( 'description' ); ?></h2>
					<?php endif; ?>
				</div><!-- .site-branding -->
                               <!-- <img src="http://auctioncool.com/wp-content/uploads/2016/05/ebay.png" width="50" style="float:bottom;" />-->
			</div><!-- .site-branding-container -->

			<nav id="site-navigation" class="main-navigation" role="navigation">
				<?php do_action('ultra_before_nav') ?>
				<?php wp_nav_menu( array( 'theme_location' => 'primary' ) ); ?>
				<?php if ( siteorigin_setting( 'navigation_menu_search' ) ) : ?>
					<div class="menu-search">
						<div class="search-icon"></div>
						<form method="get" class="searchform" action="<?php echo esc_url( home_url( '/' ) ); ?>" role="search">
							<input type="text" class="field" name="s" value="<?php echo esc_attr( get_search_query() ); ?>" />
						</form>	
					</div><!-- .menu-search -->
				<?php endif; ?>				
			</nav><!-- #site-navigation -->
		</div><!-- .container -->
	</header><!-- #masthead -->

	<?php
	$after_header = apply_filters( 'ultra_after_header', '' );

	if ( siteorigin_setting( 'header_sticky' ) ) {
		ultra_site_header_sentinel();
		echo $after_header;
	} else {
		echo $after_header;
	}
	?>
</div>
	<?php ultra_render_slider(); ?>

	<div id="content" class="site-content">

		<?php if ( class_exists( 'WooCommerce' ) && is_woocommerce() ) { get_template_part( 'parts/woocommerce-title' ); } ?>